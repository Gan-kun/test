package com.virtualpairprogrammers.services;

public class CustomerNotFoundException extends Exception {

}
