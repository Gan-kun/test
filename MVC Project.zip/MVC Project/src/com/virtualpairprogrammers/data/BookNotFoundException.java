package com.virtualpairprogrammers.data;

public class BookNotFoundException extends Exception {
	private static final long serialVersionUID = 4631445786801082925L;
}
